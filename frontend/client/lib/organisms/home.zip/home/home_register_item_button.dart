import 'package:client/atoms/boxes/trapezoid_box.dart';
import 'package:client/atoms/buttons/main_button.dart';
import 'package:client/core/constants/app_colors.dart';
import 'package:client/core/constants/app_text_style.dart';
import 'package:flutter/material.dart';
import 'package:iconify_flutter/iconify_flutter.dart';
import 'package:iconify_flutter/icons/mdi.dart';

class HomeRegisterItemButton extends StatelessWidget {
  final String title;
  final String subTitle;
  final VoidCallback? onTap;

  const HomeRegisterItemButton({
    super.key,
    required this.title,
    required this.subTitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap ?? () {},
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          TrapezoidBox(
            width: 320,
            height: 160,
            topPadding: 3,
            bottomPadding: 2,
            borderRadius: 20,
            isRightShort: true,
            borderColor: AppColors.black,
            borderWidth: 1.64,
            color: AppColors.primary_1,
            child: Padding(
              padding: const EdgeInsets.only(
                top: 30,
                bottom: 20,
                left: 20,
                right: 20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: AppTextStyle.medium_20()),
                  Text(subTitle, style: AppTextStyle.regular_12()),
                  Spacer(),
                  MainButton(
                    width: 42,
                    height: 42,
                    borderRadius: 10,
                    backgroundColor: AppColors.white,
                    child: Center(
                      child: Iconify(
                        Mdi.arrow_forward,
                        color: AppColors.black,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -15,
            right: 28,
            child: Image.asset("assets/images/yogi.png", width: 123),
          ),
        ],
      ),
    );
  }
}
