import 'package:client/atoms/boxes/border_box.dart';
import 'package:client/atoms/boxes/circle_box.dart';
import 'package:client/core/constants/app_colors.dart';
import 'package:client/core/constants/app_text_style.dart';
import 'package:flutter/material.dart';

class HomeSnackBar extends StatelessWidget {
  final String content;
  final Widget icon;
  const HomeSnackBar({super.key, required this.content, required this.icon});

  @override
  Widget build(BuildContext context) {
    return BorderBox(
      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      backgroundColor: AppColors.primary_3,
      borderRadius: 100,
      border: Border.all(color: AppColors.black, width: 2),
      child: Row(
        children: [
          CircleBox(backgroundColor: AppColors.secondary_2, child: icon),
          SizedBox(width: 16),
          Text(content, style: AppTextStyle.bold_14()),
        ],
      ),
    );
  }
}
