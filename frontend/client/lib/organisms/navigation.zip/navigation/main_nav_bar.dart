import 'package:client/atoms/boxes/circle_box.dart';
import 'package:client/core/constants/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:iconify_flutter/iconify_flutter.dart';
// import 'package:iconify_flutter/icons/heroicons.dart';
import 'package:iconify_flutter/icons/ph.dart';
import 'package:iconify_flutter/icons/ri.dart';

class MainNavBar extends StatelessWidget {
  const MainNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.black.withAlpha(100),
            blurRadius: 10,
            offset: Offset(0, 0),
            blurStyle: BlurStyle.outer,
          ),
        ],
        // gradient: LinearGradient(
        //   begin: Alignment.bottomCenter,
        //   end: Alignment.topCenter,
        //   colors: [
        //     Colors.red,
        //     Colors.red.withAlpha(125),
        //     Colors.red.withAlpha(0),
        //   ],
        //   stops: [0.0, 0.7, 1.0],
        // ),
        // borderRadius: BorderRadius.only(
        //   topLeft: Radius.circular(20),
        //   topRight: Radius.circular(20),
        // ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 45, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            NavIcon(
              iconStack: [
                Iconify(Ph.house_fill, size: 60, color: AppColors.secondary_1),
                Iconify(Ph.house, size: 60),
              ],
            ),
            NavIcon(
              offset: Offset(5, 4),
              angle: 14.1,
              iconStack: [
                Iconify(
                  Ph.magnifying_glass_fill,
                  size: 60,
                  color: AppColors.secondary_1,
                ),
                Iconify(Ph.magnifying_glass, size: 60),
              ],
            ),
            NavIcon(
              iconStack: [
                Iconify(Ri.user_fill, size: 60, color: AppColors.secondary_1),
                Iconify(Ri.user_line, size: 60),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class NavIcon extends StatelessWidget {
  final List<Widget> iconStack;
  final Offset? offset;
  final double? angle;

  const NavIcon({super.key, required this.iconStack, this.offset, this.angle});

  @override
  Widget build(BuildContext context) {
    return CircleBox(
      clipBehavior: Clip.hardEdge,
      size: 70,
      border: Border.all(width: 3, color: AppColors.black),
      backgroundColor: AppColors.primary_1,
      child: Transform.rotate(
        angle: angle ?? -12.3,
        child: Transform.translate(
          offset: offset ?? Offset(-3, 16),
          child: Stack(children: iconStack),
        ),
      ),
    );
  }
}
